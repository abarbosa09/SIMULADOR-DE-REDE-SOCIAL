package RedeSocial;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class RedeSocialGUI {
    private Map<String, Usuario> usuarios;
    private Usuario usuarioAtual;

    public RedeSocialGUI() {
        usuarios = new HashMap<>();
        initializeUI();
    }

    private void initializeUI() {
        JFrame frame = new JFrame("Rede Social");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = createPanel();
        frame.add(panel);

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private JPanel createPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(5, 5, 5, 5);

        JButton loginButton = new JButton("Login");
        JButton listarAmigosButton = new JButton("Listar Amigos");
        JButton enviarMensagemButton = new JButton("Enviar Mensagem");
        JButton logoutButton = new JButton("Logout");
        JButton cadastrarButton = new JButton("Cadastrar");
        JButton adicionarAmigoButton = new JButton("Adicionar Amigo");

        addComponent(panel, constraints, loginButton, 0, 0);
        addComponent(panel, constraints, listarAmigosButton, 1, 0);
        addComponent(panel, constraints, enviarMensagemButton, 0, 1);
        addComponent(panel, constraints, logoutButton, 1, 1);
        addComponent(panel, constraints, cadastrarButton, 0, 2);
        addComponent(panel, constraints, adicionarAmigoButton, 1, 2);

        loginButton.addActionListener(e -> fazerLogin());
        listarAmigosButton.addActionListener(e -> listarAmigos());
        enviarMensagemButton.addActionListener(e -> enviarMensagem());
        logoutButton.addActionListener(e -> logout());
        cadastrarButton.addActionListener(e -> cadastrarUsuario());
        adicionarAmigoButton.addActionListener(e -> adicionarAmigo());

        return panel;
    }

    private void addComponent(JPanel panel, GridBagConstraints constraints, JComponent component, int x, int y) {
        constraints.gridx = x;
        constraints.gridy = y;
        panel.add(component, constraints);
    }

    private void fazerLogin() {
        String email = JOptionPane.showInputDialog("Digite o email:");
        String senha = JOptionPane.showInputDialog("Digite a senha:");

        // Lógica para fazer login
    }

    private void listarAmigos() {
        if (usuarioAtual != null) {
            JOptionPane.showMessageDialog(null, "Listar amigos...");
            // Lógica para listar amigos
        } else {
            JOptionPane.showMessageDialog(null, "Faça o login primeiro!");
        }
    }

    private void enviarMensagem() {
        if (usuarioAtual != null) {
            String emailAmigo = JOptionPane.showInputDialog("Digite o email do amigo:");
            String mensagem = JOptionPane.showInputDialog("Digite a mensagem:");

            // Lógica para enviar mensagem
        } else {
            JOptionPane.showMessageDialog(null, "Faça o login primeiro!");
        }
    }

    private void logout() {
        usuarioAtual = null;
        JOptionPane.showMessageDialog(null, "Logout realizado com sucesso!");
    }

    private void cadastrarUsuario() {

            String nome = JOptionPane.showInputDialog("Digite o nome do novo usuário:");
            String email = JOptionPane.showInputDialog("Digite o email do novo usuário:");
            String senha = JOptionPane.showInputDialog("Digite a senha do novo usuário:");

            Usuario novoUsuario = new Usuario(nome, email, senha);
            usuarios.put(email, novoUsuario);
            JOptionPane.showMessageDialog(null, "Usuário cadastrado com sucesso!");
        }

    private void adicionarAmigo() {
        if (usuarioAtual != null) {
            String emailAmigo = JOptionPane.showInputDialog("Digite o email do amigo que deseja adicionar:");
            Usuario amigo = usuarios.get(emailAmigo);

            if (amigo != null) {
                usuarioAtual.adicionarAmigo(amigo);
                JOptionPane.showMessageDialog(null, "Amigo adicionado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Amigo não encontrado!");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Faça o login primeiro!");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(RedeSocialGUI::new);
    }
}
